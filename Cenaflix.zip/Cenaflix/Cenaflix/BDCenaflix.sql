USE cenaflix;

CREATE TABLE `filmes` (
  `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `nome` varchar(150) NOT NULL,
  `datalancamento` date NOT NULL,
  `categoria` varchar(100) NOT NULL
);

CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `nome` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `nomeepisodio` varchar(150) NOT NULL,
  `senha` varchar(10) NOT NULL,
  `tipo_de_usuario` varchar(100) NOT NULL
);

CREATE TABLE `podcasts` (
  `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `produtor` varchar(100) NOT NULL,
  `nomeepisodio` varchar(150) NOT NULL,
  `nºepisodio` int NOT NULL,
  `duracao` date NOT NULL,
  `URLrepositorio` text NOT NULL
);

SELECT * FROM filmes;

DROP TABLE usuarios;
