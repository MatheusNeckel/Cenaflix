package Filmes;

import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class FilmesDAO {

    Connection conn;
    PreparedStatement st;
    ResultSet rs;

    public boolean conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cenaflix", "root", "Leleco56789@");
            System.out.println("Conexão com banco de dados bem sucedida.");
            return true;
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Erro ao conectar: " + ex.getMessage());
            return false;
        }
    }

    public int cadastrar(Filmes filmes) {
        int status;
        try {
            st = conn.prepareStatement("INSERT INTO filmes(nome,datalancamento,categoria) VALUES(?,?,?)");
            st.setString(1, filmes.getNome());
            st.setDate(2, new Date(filmes.getData().getTime()));
            st.setString(3, filmes.getCategoria());
            status = st.executeUpdate();
            return status;
        } catch (SQLException ex) {
            System.out.println("Erro ao cadastrar: " + ex.getMessage());
            return ex.getErrorCode();
        }
    }

    public Filmes consultar(String nome) {

        try {
            Filmes filmes = new Filmes();
            st = conn.prepareStatement("SELECT * from filmes WHERE nome = ?");
            st.setString(1, nome);
            rs = st.executeQuery();
            if (rs.next()) {
                filmes.setNome(rs.getString("nome"));
                filmes.setData(rs.getDate("data"));
                filmes.setCategoria(rs.getString("categoria"));
                return filmes;
            } else {
                return null;
            }
        } catch (SQLException ex) {
            System.out.println("Erro ao conectar: " + ex.getMessage());
            return null;
        }
    }

    public boolean excluir(String nome) {
        try {
            st = conn.prepareStatement("DELETE FROM filmes WHERE nome = ?");
            st.setString(1, nome);
            st.executeUpdate();
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }

    public int atualizar(Filmes filmes) {
        int status;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/mm/dd");
        try {
            st = conn.prepareStatement("UPDATE videos SET nome = ?, datalancamento = ?, categoria = ? where nome = ?");
            st.setString(1, filmes.getNome());
            st.setString(2, sdf.format(filmes.getData()));
            st.setString(3, filmes.getCategoria());
            status = st.executeUpdate();
            return status;
        } catch (SQLException ex) {
            System.out.println(ex.getErrorCode());
            return ex.getErrorCode();
        }
    }

    public void desconectar() {
        try {
            conn.close();
        } catch (SQLException ex) {

        }
    }

    public List<Filmes> buscarFilmesPorCategoria(String categoria) {
        String sql = "SELECT * FROM filmes WHERE categoria LIKE ?";
        List<Filmes> listaFilmes = new ArrayList<>();
        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, "%" + categoria + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Filmes filmes = new Filmes();

                filmes.setNome(rs.getString("nome"));
                filmes.setData(rs.getDate("datalancamento"));
                filmes.setCategoria(rs.getString("categoria"));

                listaFilmes.add(filmes);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaFilmes;
    }

}
