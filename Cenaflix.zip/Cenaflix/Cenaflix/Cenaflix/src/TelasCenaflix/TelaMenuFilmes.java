package TelasCenaflix;

import TelasFilmes.TelaCadastroBD;
import TelasFilmes.TelaConsultaBD;

public class TelaMenuFilmes extends javax.swing.JFrame {

    public TelaMenuFilmes() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnCadastrarFilme = new javax.swing.JButton();
        btnConsultarFilme = new javax.swing.JButton();
        lblCenaflix = new javax.swing.JLabel();
        lblFilmes = new javax.swing.JLabel();
        lblEscolhaOpcao = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnCadastrarFilme.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnCadastrarFilme.setText("CADASTRAR FILME");
        btnCadastrarFilme.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarFilmeActionPerformed(evt);
            }
        });
        jPanel1.add(btnCadastrarFilme, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, -1, -1));

        btnConsultarFilme.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnConsultarFilme.setText("CONSULTAR FILME");
        btnConsultarFilme.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarFilmeActionPerformed(evt);
            }
        });
        jPanel1.add(btnConsultarFilme, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 190, -1, -1));

        lblCenaflix.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        lblCenaflix.setText("CENAFLIX");
        jPanel1.add(lblCenaflix, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 0, -1, -1));

        lblFilmes.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblFilmes.setText("FILMES");
        jPanel1.add(lblFilmes, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 50, -1, -1));

        lblEscolhaOpcao.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblEscolhaOpcao.setText("Escolha um opção:");
        jPanel1.add(lblEscolhaOpcao, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 382, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 268, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCadastrarFilmeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarFilmeActionPerformed
        TelaCadastroBD telaCadastro = new TelaCadastroBD();
        telaCadastro.setVisible(true);
    }//GEN-LAST:event_btnCadastrarFilmeActionPerformed

    private void btnConsultarFilmeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarFilmeActionPerformed
        TelaConsultaBD telaConsulta = new TelaConsultaBD();
        telaConsulta.setVisible(true);
    }//GEN-LAST:event_btnConsultarFilmeActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaMenuFilmes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrarFilme;
    private javax.swing.JButton btnConsultarFilme;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblCenaflix;
    private javax.swing.JLabel lblEscolhaOpcao;
    private javax.swing.JLabel lblFilmes;
    // End of variables declaration//GEN-END:variables
}
