package TelasFilmes;

import TelasFilmes.TelaAtualizarBD;
import Filmes.Filmes;
import Filmes.FilmesDAO;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.JOptionPane;

public class TelaConsultaBD extends javax.swing.JFrame {

    public TelaConsultaBD() {
        initComponents();
        preencherTabela();
    }

    private void preencherTabela() {
        FilmesDAO filmesDAO = new FilmesDAO();

        String categoria = txtPesquisar.getText();
        
        filmesDAO.conectar();

        List<Filmes> listaFilmes = filmesDAO.buscarFilmesPorCategoria(categoria);

        DefaultTableModel tabelaFilmes = (DefaultTableModel) tblFilmes.getModel();

        tabelaFilmes.setNumRows(0);

        tblFilmes.setRowSorter(new TableRowSorter(tabelaFilmes));
        
        for (Filmes film : listaFilmes) {
            Object[] obj = new Object[]{
                film.getNome(),
                film.getData(),
                film.getCategoria()
            };

            tabelaFilmes.addRow(obj);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblFilmes = new javax.swing.JTable();
        btnAtualizar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        lblCenaflix = new javax.swing.JLabel();
        lblConsultadeFilme = new javax.swing.JLabel();
        lblPesquisar = new javax.swing.JLabel();
        txtPesquisar = new javax.swing.JTextField();
        btnPesquisar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblFilmes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "Data de Lançamento", "Categoria"
            }
        ));
        jScrollPane1.setViewportView(tblFilmes);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 730, 380));

        btnAtualizar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnAtualizar.setText("Atualizar");
        btnAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizarActionPerformed(evt);
            }
        });
        jPanel1.add(btnAtualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 560, -1, -1));

        btnExcluir.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });
        jPanel1.add(btnExcluir, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 560, -1, -1));

        lblCenaflix.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        lblCenaflix.setText("CENAFLIX");
        jPanel1.add(lblCenaflix, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 0, -1, -1));

        lblConsultadeFilme.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblConsultadeFilme.setText("CONSULTA DE FILME");
        jPanel1.add(lblConsultadeFilme, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 50, -1, -1));

        lblPesquisar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblPesquisar.setText("Pesquisar categoria de filmes:");
        jPanel1.add(lblPesquisar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        txtPesquisar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtPesquisar.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                txtPesquisarCaretUpdate(evt);
            }
        });
        txtPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesquisarActionPerformed(evt);
            }
        });
        jPanel1.add(txtPesquisar, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, 340, -1));

        btnPesquisar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnPesquisar.setText("Pesquisar");
        btnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarActionPerformed(evt);
            }
        });
        jPanel1.add(btnPesquisar, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 120, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 750, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 608, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        FilmesDAO filmesDAO = new FilmesDAO();
        Filmes filmes = new Filmes();
        boolean status = filmesDAO.conectar();
        if (status == false) {
            JOptionPane.showMessageDialog(null, "Erro de conexão");
        } else {
            status = filmesDAO.excluir(filmes.getNome());
            if (status == true) {
                JOptionPane.showMessageDialog(null, "O filme foi excluído com sucesso!");
                String nome = filmes.getNome();
                filmesDAO.excluir(nome);
                btnExcluir.setEnabled(false);
            } else {
                JOptionPane.showMessageDialog(null, "Erro na exclusão do filme!");
            }
            filmesDAO.desconectar();
        }

    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed
        TelaAtualizarBD telaAtualizar = new TelaAtualizarBD();
        telaAtualizar.setVisible(true);
    }//GEN-LAST:event_btnAtualizarActionPerformed

    private void txtPesquisarCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_txtPesquisarCaretUpdate
        preencherTabela();
    }//GEN-LAST:event_txtPesquisarCaretUpdate

    private void txtPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesquisarActionPerformed
       
    }//GEN-LAST:event_txtPesquisarActionPerformed

    private void btnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarActionPerformed
        String categoria = txtPesquisar.getText();

        FilmesDAO filmesDAO = new FilmesDAO();
        List<Filmes> filmes = filmesDAO.buscarFilmesPorCategoria(categoria);
       
       if (filmes == null) {
            JOptionPane.showMessageDialog(this, "Filme não encontrado!");
        } else {
            preencherTabela();
        }
    }//GEN-LAST:event_btnPesquisarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaConsultaBD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaConsultaBD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaConsultaBD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaConsultaBD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaConsultaBD().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnPesquisar;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCenaflix;
    private javax.swing.JLabel lblConsultadeFilme;
    private javax.swing.JLabel lblPesquisar;
    private javax.swing.JTable tblFilmes;
    private javax.swing.JTextField txtPesquisar;
    // End of variables declaration//GEN-END:variables
}
