package TelasFilmes;

import Filmes.Filmes;
import Filmes.FilmesDAO;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

public class TelaCadastroBD extends javax.swing.JFrame {

    public TelaCadastroBD() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblCenaflix = new javax.swing.JLabel();
        lblCadastrodeFilme = new javax.swing.JLabel();
        lblNomedoFilme = new javax.swing.JLabel();
        lblData = new javax.swing.JLabel();
        lblCategoria = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        txtData = new javax.swing.JTextField();
        txtCategoria = new javax.swing.JTextField();
        btnCadastrar = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblCenaflix.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        lblCenaflix.setText("CENAFLIX");
        jPanel1.add(lblCenaflix, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 10, -1, -1));

        lblCadastrodeFilme.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblCadastrodeFilme.setText("CADASTRO DE FILME");
        jPanel1.add(lblCadastrodeFilme, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 60, -1, -1));

        lblNomedoFilme.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblNomedoFilme.setText("Nome do Filme:");
        jPanel1.add(lblNomedoFilme, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 110, -1, -1));

        lblData.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblData.setText("Data de Lançamento:");
        jPanel1.add(lblData, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, -1, -1));

        lblCategoria.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblCategoria.setText("Categoria:");
        jPanel1.add(lblCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 210, -1, -1));

        txtNome.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeActionPerformed(evt);
            }
        });
        jPanel1.add(txtNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 110, 250, -1));

        txtData.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDataActionPerformed(evt);
            }
        });
        jPanel1.add(txtData, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 160, 250, -1));

        txtCategoria.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCategoriaActionPerformed(evt);
            }
        });
        jPanel1.add(txtCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 210, 250, -1));

        btnCadastrar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnCadastrar.setText("Cadastrar");
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });
        jPanel1.add(btnCadastrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 270, -1, -1));

        btnLimpar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnLimpar.setText("Limpar");
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });
        jPanel1.add(btnLimpar, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 270, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 508, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 318, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeActionPerformed

    private void txtCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCategoriaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCategoriaActionPerformed

    private void txtDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDataActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDataActionPerformed

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnLimparActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        Filmes filmes = new Filmes();
        FilmesDAO filmesDAO = new FilmesDAO();
        boolean status;
        int resposta = 0;

        filmes.setNome(txtNome.getText());
        filmes.setCategoria(txtCategoria.getText());

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        String strData = txtData.getText();
        try {
            Date data = sdf.parse(strData);

            java.sql.Date sqlDate = new java.sql.Date(data.getTime());

            filmes.setData(sqlDate);

        } catch (ParseException ex) {
            System.out.println("Erro ao converter o texto para Date: " + ex.getMessage());
        }

        status = filmesDAO.conectar();

        if (!status) {
            JOptionPane.showMessageDialog(null, "Erro de conexão!");
        } else {
            resposta = filmesDAO.cadastrar(filmes);
            if (resposta == 1) {
                JOptionPane.showMessageDialog(null, "Dados inseridos com sucesso.");
                txtNome.setText("");
                txtData.setText("");
                txtCategoria.setText("");
            } else if (resposta == 1062) {
                JOptionPane.showMessageDialog(null, "O filme já foi cadastrado.");
            } else {
                JOptionPane.showMessageDialog(null, "Erro ao tentar inserir os dados!");
            }
            filmesDAO.desconectar();
        }
    }//GEN-LAST:event_btnCadastrarActionPerformed

    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadastroBD().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblCadastrodeFilme;
    private javax.swing.JLabel lblCategoria;
    private javax.swing.JLabel lblCenaflix;
    private javax.swing.JLabel lblData;
    private javax.swing.JLabel lblNomedoFilme;
    private javax.swing.JTextField txtCategoria;
    private javax.swing.JTextField txtData;
    private javax.swing.JTextField txtNome;
    // End of variables declaration//GEN-END:variables
}
