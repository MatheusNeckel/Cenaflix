package br.com.cenaflix.cenaflixjpa;

public class CenaflixJPA {

    public static void main(String[] args) {
    }
}
