package Usuarios;

import Podcasts.Podcasts;
import TelasCenaflixPodcast.TelaCadastroUsuario;
import br.com.cenaflix.cenaflixjpa.persistencia.JPAUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuariosJPA {

    Connection conn;
    PreparedStatement st;
    ResultSet rs;

        public static void cadastrar(Usuarios usuarios) {
        EntityManager manager = JPAUtil.conectar();
        try {
            manager.getTransaction().begin();
            manager.persist(usuarios);
            manager.getTransaction().commit();
        } catch(Exception e) {
            manager.getTransaction().rollback();
        } finally {
            JPAUtil.desconectar();
        } 
    }
    
    public static List<Usuarios> listar() {
        List<Usuarios> lista = new ArrayList<Usuarios>();
        
        EntityManager manager = JPAUtil.conectar();
        try {
            Query consulta = manager.createQuery("SELECT u FROM usuarios u");
            lista = consulta.getResultList();
        } catch(Exception e) {
            manager.getTransaction().rollback();
        } finally {
            JPAUtil.desconectar();
        } 
        return lista;
    }
    
    public static void excluir (int id) {
            EntityManager manager = JPAUtil.conectar();
            try {
                manager.getTransaction().begin();
                Usuarios u = manager.find(Usuarios.class, id);
                if (u != null) {
                    manager.remove(u);
                }
                manager.getTransaction().commit();
            } catch(Exception e) {
                manager.getTransaction().rollback();
            } finally {
                JPAUtil.desconectar();
            } 
        }
}
