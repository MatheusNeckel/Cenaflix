package TelasCenaflixPodcast;

import Podcasts.Podcasts;
import Podcasts.PodcastsJPA;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

public class TelaCadastroPodcast extends javax.swing.JFrame {

    public TelaCadastroPodcast() {
        initComponents();
    }

    public void getCadastrar() {
        btnCadastrar.setEnabled(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblCenaflix = new javax.swing.JLabel();
        lblCadastrar = new javax.swing.JLabel();
        lblProdutor = new javax.swing.JLabel();
        lblNome = new javax.swing.JLabel();
        lblNºEpisodio = new javax.swing.JLabel();
        lblDuracao = new javax.swing.JLabel();
        lblURLRepo = new javax.swing.JLabel();
        txtProdutor = new javax.swing.JTextField();
        txtNome = new javax.swing.JTextField();
        txtNºEpisodio = new javax.swing.JTextField();
        txtDuracao = new javax.swing.JTextField();
        txtURLRepo = new javax.swing.JTextField();
        btnCadastrar = new javax.swing.JButton();
        btnVerListagem = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblCenaflix.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        lblCenaflix.setText("CENAFLIX");
        jPanel1.add(lblCenaflix, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, -1, -1));

        lblCadastrar.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblCadastrar.setText("CADASTRAR PODCAST");
        jPanel1.add(lblCadastrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 60, -1, -1));

        lblProdutor.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblProdutor.setText("Produtor:");
        jPanel1.add(lblProdutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 110, -1, -1));

        lblNome.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblNome.setText("Nome do Episódio:");
        jPanel1.add(lblNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 190, -1, -1));

        lblNºEpisodio.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblNºEpisodio.setText("Nº do Episódio:");
        jPanel1.add(lblNºEpisodio, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 270, -1, -1));

        lblDuracao.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblDuracao.setText("Duração:");
        jPanel1.add(lblDuracao, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 310, -1, -1));

        lblURLRepo.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblURLRepo.setText("URL do Repositório:");
        jPanel1.add(lblURLRepo, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 390, -1, -1));

        txtProdutor.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtProdutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtProdutorActionPerformed(evt);
            }
        });
        jPanel1.add(txtProdutor, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 140, 290, -1));

        txtNome.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jPanel1.add(txtNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 220, 290, -1));

        txtNºEpisodio.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtNºEpisodio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNºEpisodioActionPerformed(evt);
            }
        });
        jPanel1.add(txtNºEpisodio, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 270, 80, -1));

        txtDuracao.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtDuracao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDuracaoActionPerformed(evt);
            }
        });
        jPanel1.add(txtDuracao, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 340, 290, -1));

        txtURLRepo.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jPanel1.add(txtURLRepo, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 420, 290, -1));

        btnCadastrar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnCadastrar.setText("Cadastrar");
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });
        jPanel1.add(btnCadastrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 470, -1, -1));

        btnVerListagem.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnVerListagem.setText("Ver Listagem");
        btnVerListagem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerListagemActionPerformed(evt);
            }
        });
        jPanel1.add(btnVerListagem, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 470, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 528, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 546, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtDuracaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDuracaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDuracaoActionPerformed

    private void txtProdutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtProdutorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtProdutorActionPerformed

    private void txtNºEpisodioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNºEpisodioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNºEpisodioActionPerformed

    private void btnVerListagemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerListagemActionPerformed
        TelaListagemPodcast tlp = new TelaListagemPodcast();
        tlp.setVisible(true);
    }//GEN-LAST:event_btnVerListagemActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        Podcasts p = new Podcasts();
        int nºEpisodio;

        nºEpisodio = Integer.parseInt(txtNºEpisodio.getText());

        p.setProdutor(txtProdutor.getText());
        p.setNomeEpisodio(txtNome.getText());
        p.setNºEpisodio(nºEpisodio);
        p.setUrlRepositorio(txtURLRepo.getText());

        PodcastsJPA.cadastrar(p);
        JOptionPane.showMessageDialog(null, "Podcast cadastrado com sucesso!");
    }//GEN-LAST:event_btnCadastrarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaCadastroPodcast.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaCadastroPodcast.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaCadastroPodcast.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaCadastroPodcast.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadastroPodcast().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnVerListagem;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblCadastrar;
    private javax.swing.JLabel lblCenaflix;
    private javax.swing.JLabel lblDuracao;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblNºEpisodio;
    private javax.swing.JLabel lblProdutor;
    private javax.swing.JLabel lblURLRepo;
    private javax.swing.JTextField txtDuracao;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtNºEpisodio;
    private javax.swing.JTextField txtProdutor;
    private javax.swing.JTextField txtURLRepo;
    // End of variables declaration//GEN-END:variables
}
