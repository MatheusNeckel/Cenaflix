package TelasCenaflixPodcast;

import Podcasts.Podcasts;
import Podcasts.PodcastsJPA;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class TelaListagemPodcast extends javax.swing.JFrame {
    
    public TelaListagemPodcast() {
        initComponents();
    }
    
    private String getIdItemSelecionado() {
        int posicao = tblPodcasts.getSelectedRow();
        
        if (posicao == -1) {
            JOptionPane.showMessageDialog(null, "Selecione um item da tabela.");
        }
        return (String) tblPodcasts.getValueAt(posicao, 0);
    }
    
    private DefaultTableModel preencherTabela(List<Podcasts> lista) {
        
        DefaultTableModel tabela = new DefaultTableModel();
        
        for (int i = 0; lista.size() > i; i++) {
            Podcasts p = lista.get(i);
            
            String[] linha = {
                Integer.toString(p.getId()),
                p.getProdutor(),
                p.getNomeEpisodio(),
                Integer.toString(p.getNºEpisodio()),
                p.getDuracao(),
                p.getUrlRepositorio()
            };
            tabela.addRow(linha);
        }
        return tabela;
    }
    
    public void getExcluir() {
        btnExcluir.setEnabled(true);
    }
    
    public void getExcluir2() {
        btnExcluir.setEnabled(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblCenaflix = new javax.swing.JLabel();
        lblListagem = new javax.swing.JLabel();
        lblPesquisa = new javax.swing.JLabel();
        txtPesquisa = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPodcasts = new javax.swing.JTable();
        btnCadastrar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblCenaflix.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        lblCenaflix.setText("CENAFLIX");
        jPanel1.add(lblCenaflix, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 10, -1, -1));

        lblListagem.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblListagem.setText("    LISTAGEM");
        jPanel1.add(lblListagem, new org.netbeans.lib.awtextra.AbsoluteConstraints(259, 60, 160, -1));

        lblPesquisa.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblPesquisa.setText("Pesquisar podcast por produtor:");
        jPanel1.add(lblPesquisa, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, -1));

        txtPesquisa.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jPanel1.add(txtPesquisa, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 110, 320, -1));

        tblPodcasts.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tblPodcasts.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Produtor", "Nome do Episódio", "Nº Episódio", "Duração", "URL do Repo"
            }
        ));
        jScrollPane1.setViewportView(tblPodcasts);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 690, 240));

        btnCadastrar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnCadastrar.setText("Cadastrar");
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });
        jPanel1.add(btnCadastrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 430, -1, -1));

        btnExcluir.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });
        jPanel1.add(btnExcluir, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 430, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 478, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        TelaCadastroPodcast tcp = new TelaCadastroPodcast();
        tcp.setVisible(true);
    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        PodcastsJPA.excluir(Integer.parseInt(getIdItemSelecionado()));
        tblPodcasts.setModel(preencherTabela(PodcastsJPA.listar()));
        jScrollPane1.setViewportView(tblPodcasts);
    }//GEN-LAST:event_btnExcluirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaListagemPodcast.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaListagemPodcast.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaListagemPodcast.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaListagemPodcast.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaListagemPodcast().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCenaflix;
    private javax.swing.JLabel lblListagem;
    private javax.swing.JLabel lblPesquisa;
    private javax.swing.JTable tblPodcasts;
    private javax.swing.JTextField txtPesquisa;
    // End of variables declaration//GEN-END:variables
}
