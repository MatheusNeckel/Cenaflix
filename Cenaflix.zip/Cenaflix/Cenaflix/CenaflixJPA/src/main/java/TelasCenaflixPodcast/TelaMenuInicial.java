package TelasCenaflixPodcast;

public class TelaMenuInicial extends javax.swing.JFrame {

    public TelaMenuInicial() {
        initComponents();
    }
    
    public void getListar() {
        btnListarPodcast.setEnabled(true);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnCadastrarPodcast = new javax.swing.JButton();
        btnListarPodcast = new javax.swing.JButton();
        lblCenaflix = new javax.swing.JLabel();
        lblFilmes = new javax.swing.JLabel();
        lblEscolhaOpcao = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnCadastrarPodcast.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnCadastrarPodcast.setText("CADASTRAR PODCAST");
        btnCadastrarPodcast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarPodcastActionPerformed(evt);
            }
        });
        jPanel1.add(btnCadastrarPodcast, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 130, -1, -1));

        btnListarPodcast.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnListarPodcast.setText("LISTAR PODCAST");
        btnListarPodcast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarPodcastActionPerformed(evt);
            }
        });
        jPanel1.add(btnListarPodcast, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 190, -1, -1));

        lblCenaflix.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        lblCenaflix.setText("CENAFLIX");
        jPanel1.add(lblCenaflix, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 0, -1, -1));

        lblFilmes.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblFilmes.setText("PODCASTS");
        jPanel1.add(lblFilmes, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 50, -1, -1));

        lblEscolhaOpcao.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblEscolhaOpcao.setText("Escolha um opção:");
        jPanel1.add(lblEscolhaOpcao, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 382, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 268, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCadastrarPodcastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarPodcastActionPerformed
        TelaCadastroPodcast telaCadastro = new TelaCadastroPodcast();
        telaCadastro.setVisible(true);
    }//GEN-LAST:event_btnCadastrarPodcastActionPerformed

    private void btnListarPodcastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarPodcastActionPerformed
        TelaListagemPodcast telaListagem = new TelaListagemPodcast();
        telaListagem.setVisible(true);
    }//GEN-LAST:event_btnListarPodcastActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaMenuInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaMenuInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaMenuInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaMenuInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaMenuInicial().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrarPodcast;
    private javax.swing.JButton btnListarPodcast;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblCenaflix;
    private javax.swing.JLabel lblEscolhaOpcao;
    private javax.swing.JLabel lblFilmes;
    // End of variables declaration//GEN-END:variables
}
