package Podcasts;

import br.com.cenaflix.cenaflixjpa.persistencia.JPAUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import java.util.ArrayList;
import java.util.List;

public class PodcastsJPA {
    public static void cadastrar(Podcasts podcasts) {
        EntityManager manager = JPAUtil.conectar();
        try {
            manager.getTransaction().begin();
            manager.persist(podcasts);
            manager.getTransaction().commit();
        } catch(Exception e) {
            manager.getTransaction().rollback();
        } finally {
            JPAUtil.desconectar();
        } 
    }
    
    public static List<Podcasts> listar() {
        List<Podcasts> lista = new ArrayList<Podcasts>();
        
        EntityManager manager = JPAUtil.conectar();
        try {
            Query consulta = manager.createQuery("SELECT p FROM podcasts p");
            lista = consulta.getResultList();
        } catch(Exception e) {
            manager.getTransaction().rollback();
        } finally {
            JPAUtil.desconectar();
        } 
        return lista;
    }
    
        public static List<Podcasts> buscarPorProdutor (String filtro) {
            List<Podcasts> lista = new ArrayList<Podcasts>();

            EntityManager manager = JPAUtil.conectar();
            try {
                Query consulta = manager.createQuery("SELECT p FROM podcasts p WHERE (:produtor is null OR p.produtor LIKE :produtor)");
                consulta.setParameter("produtor", filtro.isEmpty() ? null : "%" + filtro + "%");
                lista = consulta.getResultList();
            } catch(Exception e) {
                manager.getTransaction().rollback();
            } finally {
                JPAUtil.desconectar();
            } 
            return lista;
        }
        
        public static void excluir (int id) {
            EntityManager manager = JPAUtil.conectar();
            try {
                manager.getTransaction().begin();
                Podcasts p = manager.find(Podcasts.class, id);
                if (p != null) {
                    manager.remove(p);
                }
                manager.getTransaction().commit();
            } catch(Exception e) {
                manager.getTransaction().rollback();
            } finally {
                JPAUtil.desconectar();
            } 
        }
}
