package Podcasts;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import java.sql.Date;

@Entity(name = "podcasts")
public class Podcasts {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String produtor;
    private String nomeEpisodio;
    private int nºEpisodio;
    private String duracao;
    private String urlRepositorio;

    public Podcasts() {
    }

    public Podcasts(int id, String produtor, String nomeEpisodio, int nºEpisodio, String duracao, String urlRepositorio) {
        this.produtor = produtor;
        this.nomeEpisodio = nomeEpisodio;
        this.nºEpisodio = nºEpisodio;
        this.duracao = duracao;
        this.urlRepositorio = urlRepositorio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProdutor() {
        return produtor;
    }

    public void setProdutor(String produtor) {
        this.produtor = produtor;
    }

    public String getNomeEpisodio() {
        return nomeEpisodio;
    }

    public void setNomeEpisodio(String nomeEpisodio) {
        this.nomeEpisodio = nomeEpisodio;
    }

    public int getNºEpisodio() {
        return nºEpisodio;
    }

    public void setNºEpisodio(int nºEpisodio) {
        this.nºEpisodio = nºEpisodio;
    }

    public String getDuracao() {
        return duracao;
    }

    public void setDuracao(String duracao) {
        this.duracao = duracao;
    }

    public String getUrlRepositorio() {
        return urlRepositorio;
    }

    public void setUrlRepositorio(String urlRepositorio) {
        this.urlRepositorio = urlRepositorio;
    }

}
